package com.hlc.coche;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CocheApplication {

	public static void main(String[] args) {
		SpringApplication.run(CocheApplication.class, args);
	}

}
